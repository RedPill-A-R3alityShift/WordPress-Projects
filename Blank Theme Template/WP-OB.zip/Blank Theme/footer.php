<!--		<div id="footer">

			<h3>This is the FOOTER PHP<br>
			&copy;<?php echo date("Y"); echo " "; bloginfo('name'); ?>
			</h3>
		</div>

	</div>

	<?php wp_footer(); ?>
	-->
	<!-- Don't forget analytics -->
	
</body>

</html>